# Dark Mode Toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/Faisal-Nawaz-the-bold/pen/JjVQbgd](https://codepen.io/Faisal-Nawaz-the-bold/pen/JjVQbgd).

A simple dark mode toggle using localStorage to store and apply settings when the page is loaded.